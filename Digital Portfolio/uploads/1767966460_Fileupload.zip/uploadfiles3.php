<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload Example</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <h1>Upload a File (GIF, JPG, or JPEG only, max 2MB)</h1>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" enctype="multipart/form-data">
        <label for="uploadedFile">Select a file:</label>
        <input type="file" name="uploadedFile" id="uploadedFile" required>
        <br><br>
        <input type="submit" value="Upload File">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['uploadedFile'])) {
        $fileSize = (2*1024*1024); //2Mb

        //#### Upload with restrictions and move to folder####
        //If there are no errors (error == 0), continue
        if ($_FILES["uploadedFile"]["error"] == 0)
        {
            //The user may only upload a file with a size under the defined size:
            if ($_FILES["uploadedFile"]["size"] < $fileSize)
            {
                //The user may only upload gif or .jpeg files
                $acceptedFileTypes = ["image/gif", "image/jpg", "image/jpeg", "image/pdf","image/docx"];

                $fileinfo = finfo_open(FILEINFO_MIME_TYPE);
                $uploadedFileType = finfo_file($fileinfo, $_FILES["uploadedFile"]["tmp_name"]);

                //A shorter version of line 13 - 14
                //$uploadedFileType = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["uploadedFile"]["tmp_name"]);

                //If the type is in the array, proceed
                if(in_array($uploadedFileType, $acceptedFileTypes))
                {
                    if (!file_exists("upload/" . $_FILES["uploadedFile"]["name"])){
                        //If the file does not exist, transfer the file from the temporary folder to the upload folder using the original upload name
                        if(move_uploaded_file($_FILES["uploadedFile"]["tmp_name"], "upload/". $_FILES["uploadedFile"]["name"])){
                            echo "<p>Upload successful!</p>";
                            echo "<p>Upload: " . $_FILES["uploadedFile"]["name"] . "</p>";
                            echo "<p>Type: " . $uploadedFileType . "</p>";
                            echo "<p>Size: " . ($_FILES["uploadedFile"]["size"] / 1024) . " Kb</p>";
                            echo "<p>Stored temporarily in: " . $_FILES["uploadedFile"]["tmp_name"] . "</p>";
                            echo "<p>Stored permanently in: upload/" . $_FILES["uploadedFile"]["name"] . "</p>";
                            // Display the uploaded image
                            echo "<p><img src='upload/" . $_FILES["uploadedFile"]["name"] . "' alt='Uploaded Image' style='max-width: 300px; border: 1px solid #ccc;'></p>";
                        }else{
                            echo "<p>Something went wrong while uploading.</p>";
                        }
                    }else{
                        echo "<p>" . $_FILES["uploadedFile"]["name"] . " already exists.</p>";
                    }
                }else{
                    echo "<p>Invalid file type. Must be gif, jpg or jpeg.</p>";
                }
            }else{
                echo "<p>Invalid file size. Must be less than " . $fileSize/1024/1024 . "Mb.</p>";
            }
        }else{
            echo "<p>Error: " . $_FILES["uploadedFile"]["error"] . "</p>";
            echo "<p>See <a href='https://www.php.net/manual/en/features.file-upload.errors.php' target='_BLANK'>PHP.net</a> for the explanation of the error messages.</p>";
        }
    }
    
    ?>
</body>
</html> 


